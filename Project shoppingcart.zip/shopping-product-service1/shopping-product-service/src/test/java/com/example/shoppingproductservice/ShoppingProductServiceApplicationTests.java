package com.example.shoppingproductservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

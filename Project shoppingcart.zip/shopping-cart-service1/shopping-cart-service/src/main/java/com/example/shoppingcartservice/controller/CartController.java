package com.example.shoppingcartservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.shoppingcartservice.entity.Cart;
import com.example.shoppingcartservice.repo.CartRepo;

@RestController
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	CartRepo cartRepo;
	
	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Cart>> getProducts(){
		return new ResponseEntity<List<Cart>>(cartRepo.findAll(), HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public ResponseEntity<Cart> addProduct(@RequestBody Cart cart){
		return new ResponseEntity<Cart>(cartRepo.save(cart), HttpStatus.OK);
	}
	
	@GetMapping(value = "/getByName/{name}")
	public Object getByName(@PathVariable String name) {
		Object response = restTemplate.exchange("http://product-service/prod/getByName/{name}", HttpMethod.GET, null, new ParameterizedTypeReference<Object>() {
		}, name).getBody();
		return response;
	}
	
	@GetMapping("/getByCName/{cname}")
	public ResponseEntity<Optional<Cart>> getByCName(
			@PathVariable(value = "cname") String cname){
		Optional<Cart> cart = cartRepo.findById(cname);
		return ResponseEntity.ok().body(cart);
	}
}

@Configuration
class config{
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}